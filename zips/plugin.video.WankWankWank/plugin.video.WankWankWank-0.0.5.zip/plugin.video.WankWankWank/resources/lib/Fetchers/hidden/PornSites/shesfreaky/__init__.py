# -*- coding: UTF-8 -*-
from .shefreaky import ShesFreaky

if __name__ == '__main__':
    module = ShesFreaky()
    module.download_category_input_from_user()
