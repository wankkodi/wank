# -*- coding: UTF-8 -*-
from .hotgirlclub import HotGirlClub

if __name__ == '__main__':
    module = HotGirlClub()
    module.download_category_input_from_user()
