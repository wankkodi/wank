# -*- coding: UTF-8 -*-
from .cliphunter import ClipHunter

if __name__ == '__main__':
    module = ClipHunter()
    module.download_category_input_from_user()
