# -*- coding: UTF-8 -*-
from .collectionofbestporn import CollectionOfBestPorn

if __name__ == '__main__':
    module = CollectionOfBestPorn()
    module.download_category_input_from_user()
