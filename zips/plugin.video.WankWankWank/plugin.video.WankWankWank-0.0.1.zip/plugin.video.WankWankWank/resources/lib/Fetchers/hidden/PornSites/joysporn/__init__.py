# -*- coding: UTF-8 -*-
from .joysporn import JoysPorn

if __name__ == '__main__':
    module = JoysPorn()
    module.download_category_input_from_user()
