# -*- coding: UTF-8 -*-
from .hqporner import HQPorner

if __name__ == '__main__':
    module = HQPorner()
    module.download_category_input_from_user()
