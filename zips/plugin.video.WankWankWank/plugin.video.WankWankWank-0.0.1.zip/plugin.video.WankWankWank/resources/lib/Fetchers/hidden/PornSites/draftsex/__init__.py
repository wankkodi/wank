# -*- coding: UTF-8 -*-
from .draftsex import DraftSex

if __name__ == '__main__':
    module = DraftSex()
    module.download_category_input_from_user()
