# -*- coding: UTF-8 -*-
from .base import BaseClass, BaseClass2, BaseClass3
# from .pornline import PornPine
from .laidhub import LaidHub
from .nudez import Nudez
from .hypnotube import HypnoTube
from .handjobhub import HandJobHub
from .wetsins import WetSins
from .xnxxhamster import XnxxHamster
from .drporntube import DrPornTube
from .sinclips import SinClips
from .pornxio import PornXio
from .pornrabbit import PornRabbit
from .pornwatchers import PornWatchers
from .stileproject import StileProject
from .eroxia import Eroxia

# todo: to make more precise test...

if __name__ == '__main__':
    # module = LaidHub()
    # module = Nudez()
    # module = HypnoTube()
    # module = HandJobHub()
    # module = WetSins()
    # module = XnxxHamster()
    # module = DrPornTube()
    # module = SinClips()
    # module = PornRabbit()
    # module = PornWatchers()
    # module = StileProject()
    module = PornXio()
    module.download_category_input_from_user(use_web_server=True)
