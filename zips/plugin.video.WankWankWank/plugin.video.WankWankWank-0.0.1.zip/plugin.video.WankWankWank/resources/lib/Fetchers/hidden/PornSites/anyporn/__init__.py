# -*- coding: UTF-8 -*-
from .anyporn import AnyPorn
from .analdin import Analdin
from .pervertsluts import PervertSluts
from .fapster import Fapster
from .pornrewind import PornRewind
from .hellporno import HellPorno
from .alphaporno import AlphaPorno
from .magatubexxx import MegaTubeXXX
from .tubewolf import TubeWolf
from .xbabe import XBabe
from .bravoporn import BravoPorn
from .xcum import XCum
from .hellmoms import HellMoms
from .pornplus import PornPlus
from .tropictube import TropicTube
from .zedporn import ZedPorn
from .pornfd import PornFd
from .zerodaysporn import ZeroDaysPorn
from .pornbimbo import PornBimbo
from .boundhub import BoundHub
from .eroclips import EroClips
from .camvideostv import CamVideosTv
from .anonv import AnonV
from .mrdeepfake import MrDeepFake
from .ebony8 import Ebony8
from .camuploads import CamUploads
from .porn7 import Porn7
from .adultcartoons import AdultCartoons
from .movisand import MoviesAnd
from .interracial import Interracial
from .deviants import Deviants
from .punishbang import PunishBang
from .bravoteens import BravoTeens
from .madthumbs import MadThumbs
from .vqtube import VQTube
from .xozilla import Xozilla
from .slutload import SlutLoad
from .sex3 import Sex3
from .anysex import AnySex
from .crocotube import CrocoTube
from .watchmygftv import WatchMyGfTv
from .watchmyexgf import WatchMyExGf
from .pornodep import PornoDep
from .watchmygfme import WatchMyGfMe

# Internet tools

# Regex

# Json

# Nodes

# Math

# Time

# External Fetchers

# ID generator


if __name__ == '__main__':
    # module = AnyPorn()
    # module = AlphaPorno()
    # module = TubeWolf()
    # module = PervertSluts()
    # module = Analdin()
    # module = Fapster()
    # module = HellPorno()
    # module = XBabe()
    # module = BravoPorn()
    # module = XCum()
    # module = HellMoms()
    # module = PornPlus()
    # module = BravoTeens()
    # module = MadThumbs()
    # module = VQTube()
    # module = Xozilla()
    # module = SlutLoad()
    # module = Sex3()
    # module = AnySex()
    module = CrocoTube()
    module.download_category_input_from_user(use_web_server=True)
