# -*- coding: UTF-8 -*-
from .lovehomeporn import LoveHomePorn

if __name__ == '__main__':
    module = LoveHomePorn()
    module.download_category_input_from_user(use_web_server=True)
