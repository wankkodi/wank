# -*- coding: UTF-8 -*-
from .xhamster import XHamster

if __name__ == '__main__':
    module = XHamster()
    module.download_category_input_from_user(use_web_server=False)

