# -*- coding: UTF-8 -*-
from .porndoe import PornDoe

if __name__ == '__main__':
    module = PornDoe()
    module.download_category_input_from_user(use_web_server=True)
