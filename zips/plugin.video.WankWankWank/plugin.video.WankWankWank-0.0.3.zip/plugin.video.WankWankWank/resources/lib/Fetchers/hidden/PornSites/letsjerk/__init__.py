# -*- coding: UTF-8 -*-
from .letsjerk import LetsJerk

if __name__ == '__main__':
    module = LetsJerk()
    module.download_category_input_from_user()
