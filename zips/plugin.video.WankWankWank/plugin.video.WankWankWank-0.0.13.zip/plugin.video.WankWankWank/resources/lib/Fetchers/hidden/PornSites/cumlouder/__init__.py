# -*- coding: UTF-8 -*-
from .cumlouder import CumLouder

if __name__ == '__main__':
    module = CumLouder()
    module.download_category_input_from_user()
