# -*- coding: UTF-8 -*-
from .sport1 import Sport1

if __name__ == '__main__':
    sport1 = Sport1()
    sport1.download_category_input_from_user()
