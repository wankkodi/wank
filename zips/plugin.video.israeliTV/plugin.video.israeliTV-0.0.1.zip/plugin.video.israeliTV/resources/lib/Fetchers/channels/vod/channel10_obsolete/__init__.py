# -*- coding: UTF-8 -*-
from .channel10 import Channel10

if __name__ == '__main__':
    channel10 = Channel10()
    channel10.download_category_input_from_user()
