# -*- coding: UTF-8 -*-
from .one import One

if __name__ == '__main__':
    one = One()
    one.download_category_input_from_user()
