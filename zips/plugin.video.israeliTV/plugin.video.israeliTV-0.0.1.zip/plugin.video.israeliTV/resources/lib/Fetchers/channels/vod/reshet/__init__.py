# -*- coding: UTF-8 -*-
from .reshet import Reshet

if __name__ == '__main__':
    reshet = Reshet()
    reshet.download_category_input_from_user()
