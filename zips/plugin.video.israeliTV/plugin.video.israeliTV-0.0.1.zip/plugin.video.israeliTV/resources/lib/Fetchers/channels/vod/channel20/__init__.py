# -*- coding: UTF-8 -*-
from .channel20 import Channel20

if __name__ == '__main__':
    channel20 = Channel20()
    channel20.download_category_input_from_user()
