# -*- coding: UTF-8 -*-
from .sport5 import Sport5

if __name__ == '__main__':
    sport5 = Sport5()
    sport5.download_category_input_from_user()
