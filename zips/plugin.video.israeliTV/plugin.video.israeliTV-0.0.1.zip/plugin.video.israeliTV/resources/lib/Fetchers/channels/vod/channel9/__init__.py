# -*- coding: UTF-8 -*-
from .channel9 import Channel9

if __name__ == '__main__':
    channel9 = Channel9()
    channel9.download_category_input_from_user()
